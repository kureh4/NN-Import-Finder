using System.IO;
using UnityEditor;
using UnityEngine;

namespace NekoNeko.Tools.ImportFinder
{
    /// <summary>
    /// Cleans files/folders left by older NN - Import Finder packages.
    /// Runs after each domain load so upgrading from an older layout is automatic.
    /// </summary>
    [InitializeOnLoad]
    internal static class NNImportFinderMigration
    {
        private static readonly string[] LegacyAssetPaths =
        {
            // README is no longer distributed.
            "Assets/nekoneko/NN - Import Finder/README.txt",

            // Older official install location.
            "Assets/nekoneko/NN_ImportFinder",

            // Early test package location.
            "Assets/NN_ImportFinder"
        };

        static NNImportFinderMigration()
        {
            EditorApplication.delayCall += CleanupLegacyAssets;
        }

        private static void CleanupLegacyAssets()
        {
            bool usedFileSystemFallback = false;

            foreach (string assetPath in LegacyAssetPaths)
            {
                if (AssetDatabase.IsValidFolder(assetPath) || AssetDatabase.LoadMainAssetAtPath(assetPath) != null)
                {
                    AssetDatabase.DeleteAsset(assetPath);
                    continue;
                }

                // Fallback for a malformed early package that could leave an untracked file/folder.
                string absolutePath = Path.GetFullPath(assetPath);
                try
                {
                    if (File.Exists(absolutePath))
                    {
                        File.Delete(absolutePath);
                        usedFileSystemFallback = true;
                    }
                    else if (Directory.Exists(absolutePath))
                    {
                        Directory.Delete(absolutePath, true);
                        usedFileSystemFallback = true;
                    }

                    string metaPath = absolutePath + ".meta";
                    if (File.Exists(metaPath))
                    {
                        File.Delete(metaPath);
                        usedFileSystemFallback = true;
                    }
                }
                catch (IOException ex)
                {
                    Debug.LogWarning($"[NN - Import Finder] 旧ファイルの削除に失敗しました: {assetPath}\n{ex.Message}");
                }
                catch (System.UnauthorizedAccessException ex)
                {
                    Debug.LogWarning($"[NN - Import Finder] 旧ファイルの削除に失敗しました: {assetPath}\n{ex.Message}");
                }
            }

            if (usedFileSystemFallback)
                AssetDatabase.Refresh();
        }
    }
}
