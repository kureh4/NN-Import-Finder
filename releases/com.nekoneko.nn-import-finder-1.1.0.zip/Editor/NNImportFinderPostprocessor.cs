using UnityEditor;

namespace NekoNeko.Tools.ImportFinder
{
    internal sealed class NNImportFinderPostprocessor : AssetPostprocessor
    {
        private static void OnPostprocessAllAssets(
            string[] importedAssets,
            string[] deletedAssets,
            string[] movedAssets,
            string[] movedFromAssetPaths,
            bool didDomainReload)
        {
            NNImportFinderSession.RegisterImportedAssets(importedAssets);
        }
    }
}
