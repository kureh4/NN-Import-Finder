using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NekoNeko.Tools.ImportFinder
{
    [InitializeOnLoad]
    internal static class NNImportFinderSession
    {
        private const string KeyPrefix = "NekoNeko.NNImportFinder.v1.";
        private const string HistoryKey = KeyPrefix + "History";
        private const string ImportActiveKey = KeyPrefix + "ImportActive";
        private const string PendingPathsKey = KeyPrefix + "PendingPaths";
        private const int MaxHistory = 20;

        [Serializable]
        private sealed class HistoryData
        {
            public List<HistoryEntry> entries = new List<HistoryEntry>();
        }

        [Serializable]
        private sealed class StringListData
        {
            public List<string> items = new List<string>();
        }

        [Serializable]
        internal sealed class HistoryEntry
        {
            public string path;
            public string displayName;
        }

        static NNImportFinderSession()
        {
            AssetDatabase.importPackageStarted -= OnImportPackageStarted;
            AssetDatabase.importPackageCompleted -= OnImportPackageCompleted;
            AssetDatabase.importPackageCancelled -= OnImportPackageCancelled;
            AssetDatabase.importPackageFailed -= OnImportPackageFailed;

            AssetDatabase.importPackageStarted += OnImportPackageStarted;
            AssetDatabase.importPackageCompleted += OnImportPackageCompleted;
            AssetDatabase.importPackageCancelled += OnImportPackageCancelled;
            AssetDatabase.importPackageFailed += OnImportPackageFailed;
        }

        internal static IReadOnlyList<HistoryEntry> GetHistory()
        {
            return LoadHistory().entries;
        }

        internal static void RegisterImportedAssets(string[] importedAssets)
        {
            if (!SessionState.GetBool(ImportActiveKey, false) || importedAssets == null || importedAssets.Length == 0)
                return;

            StringListData pending = LoadPendingPaths();
            HashSet<string> unique = new HashSet<string>(pending.items, StringComparer.OrdinalIgnoreCase);

            foreach (string rawPath in importedAssets)
            {
                string path = NormalizeAssetPath(rawPath);
                if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal))
                    continue;

                unique.Add(path);
            }

            pending.items = unique.ToList();
            SavePendingPaths(pending);
        }

        private static void OnImportPackageStarted(string packageName)
        {
            SessionState.SetBool(ImportActiveKey, true);
            SavePendingPaths(new StringListData());
        }

        private static void OnImportPackageCompleted(string packageName)
        {
            try
            {
                StringListData pending = LoadPendingPaths();
                List<string> folderPaths = ResolveDisplayFolders(pending.items);

                if (folderPaths.Count > 0)
                    AddHistory(folderPaths);
            }
            finally
            {
                ClearPendingImport();
                EditorApplication.delayCall += NNImportFinderWindow.RepaintOpenWindows;
            }
        }

        private static void OnImportPackageCancelled(string packageName)
        {
            ClearPendingImport();
            EditorApplication.delayCall += NNImportFinderWindow.RepaintOpenWindows;
        }

        private static void OnImportPackageFailed(string packageName, string errorMessage)
        {
            ClearPendingImport();
            EditorApplication.delayCall += NNImportFinderWindow.RepaintOpenWindows;
        }

        private static void ClearPendingImport()
        {
            SessionState.SetBool(ImportActiveKey, false);
            SessionState.EraseString(PendingPathsKey);
        }

        private static void AddHistory(IEnumerable<string> folderPaths)
        {
            HistoryData data = LoadHistory();

            foreach (string folderPath in folderPaths.Reverse())
            {
                string normalized = NormalizeAssetPath(folderPath).TrimEnd('/');
                if (string.IsNullOrEmpty(normalized))
                    continue;

                data.entries.RemoveAll(e => string.Equals(e.path, normalized, StringComparison.OrdinalIgnoreCase));
                data.entries.Insert(0, new HistoryEntry
                {
                    path = normalized,
                    displayName = GetDisplayName(normalized)
                });
            }

            if (data.entries.Count > MaxHistory)
                data.entries.RemoveRange(MaxHistory, data.entries.Count - MaxHistory);

            SessionState.SetString(HistoryKey, JsonUtility.ToJson(data));
        }

        private static HistoryData LoadHistory()
        {
            string json = SessionState.GetString(HistoryKey, string.Empty);
            if (string.IsNullOrEmpty(json))
                return new HistoryData();

            try
            {
                HistoryData data = JsonUtility.FromJson<HistoryData>(json);
                if (data == null || data.entries == null)
                    return new HistoryData();

                return data;
            }
            catch
            {
                return new HistoryData();
            }
        }

        private static StringListData LoadPendingPaths()
        {
            string json = SessionState.GetString(PendingPathsKey, string.Empty);
            if (string.IsNullOrEmpty(json))
                return new StringListData();

            try
            {
                StringListData data = JsonUtility.FromJson<StringListData>(json);
                if (data == null || data.items == null)
                    return new StringListData();

                return data;
            }
            catch
            {
                return new StringListData();
            }
        }

        private static void SavePendingPaths(StringListData data)
        {
            SessionState.SetString(PendingPathsKey, JsonUtility.ToJson(data));
        }

        private static List<string> ResolveDisplayFolders(IEnumerable<string> importedPaths)
        {
            List<string> normalized = importedPaths
                .Where(p => !string.IsNullOrWhiteSpace(p))
                .Select(NormalizeAssetPath)
                .Where(p => p == "Assets" || p.StartsWith("Assets/", StringComparison.Ordinal))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (normalized.Count == 0)
                return new List<string>();

            // フォルダ自体のImport通知は共通パスを親側へ引き上げやすいため、
            // まず実ファイルだけからImport先を判定する。
            List<string> filePaths = normalized
                .Where(p => !AssetDatabase.IsValidFolder(p))
                .ToList();

            IEnumerable<string> sourcePaths = filePaths.Count > 0 ? filePaths : normalized;

            List<string> directories = sourcePaths
                .Select(ToContainingFolder)
                .Where(p => !string.IsNullOrEmpty(p))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (directories.Count == 0)
                return new List<string>();

            string common = GetCommonDirectory(directories);
            if (!string.Equals(common, "Assets", StringComparison.OrdinalIgnoreCase))
                return new List<string> { common };

            // 複数のAssets直下フォルダへ同時にImportされた場合は、
            // Assetsだけでは場所が分かりにくいので各ルートを個別表示する。
            HashSet<string> roots = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            bool hasDirectAsset = false;

            foreach (string dir in directories)
            {
                if (string.Equals(dir, "Assets", StringComparison.OrdinalIgnoreCase))
                {
                    hasDirectAsset = true;
                    continue;
                }

                string[] parts = dir.Split('/');
                if (parts.Length >= 2)
                    roots.Add("Assets/" + parts[1]);
            }

            if (hasDirectAsset)
                roots.Add("Assets");

            return roots.OrderBy(GetDisplayName, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static string ToContainingFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path))
                return path.TrimEnd('/');

            string directory = Path.GetDirectoryName(path);
            if (string.IsNullOrEmpty(directory))
                return "Assets";

            return NormalizeAssetPath(directory).TrimEnd('/');
        }

        private static string GetCommonDirectory(IReadOnlyList<string> directories)
        {
            string[] first = directories[0].Split('/');
            int commonLength = first.Length;

            for (int i = 1; i < directories.Count; i++)
            {
                string[] current = directories[i].Split('/');
                commonLength = Math.Min(commonLength, current.Length);

                for (int part = 0; part < commonLength; part++)
                {
                    if (!string.Equals(first[part], current[part], StringComparison.OrdinalIgnoreCase))
                    {
                        commonLength = part;
                        break;
                    }
                }
            }

            if (commonLength <= 0)
                return "Assets";

            return string.Join("/", first.Take(commonLength));
        }

        private static string GetDisplayName(string assetPath)
        {
            string normalized = NormalizeAssetPath(assetPath).TrimEnd('/');
            if (string.Equals(normalized, "Assets", StringComparison.OrdinalIgnoreCase))
                return "Assets";

            string name = Path.GetFileName(normalized);
            return string.IsNullOrEmpty(name) ? normalized : name;
        }

        private static string NormalizeAssetPath(string path)
        {
            return string.IsNullOrEmpty(path) ? string.Empty : path.Replace('\\', '/');
        }
    }
}
