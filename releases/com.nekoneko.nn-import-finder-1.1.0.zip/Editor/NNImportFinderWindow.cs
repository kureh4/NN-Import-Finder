using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace NekoNeko.Tools.ImportFinder
{
    internal sealed class NNImportFinderWindow : EditorWindow
    {
        private Vector2 scrollPosition;

        [MenuItem("ねこねこツール/NN - Import Finder", false, 100)]
        private static void OpenWindow()
        {
            NNImportFinderWindow window = GetWindow<NNImportFinderWindow>();
            window.titleContent = new GUIContent("NN - Import Finder");
            window.minSize = new Vector2(280f, 170f);
            window.Show();
        }

        private void OnEnable()
        {
            titleContent = new GUIContent("NN - Import Finder");
            minSize = new Vector2(280f, 170f);
        }

        private void OnGUI()
        {
            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("最近のImport", EditorStyles.boldLabel);
            EditorGUILayout.Space(4f);

            IReadOnlyList<NNImportFinderSession.HistoryEntry> history = NNImportFinderSession.GetHistory();

            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);

            if (history.Count == 0)
            {
                EditorGUILayout.HelpBox(
                    "何もありません\n\nこのUnityセッション中に .unitypackage をImportすると、ここにフォルダが表示されます。",
                    MessageType.Info);
            }
            else
            {
                foreach (NNImportFinderSession.HistoryEntry entry in history)
                    DrawHistoryButton(entry);
            }

            EditorGUILayout.EndScrollView();

            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField(
                "履歴はUnityを終了すると自動で消えます。",
                EditorStyles.miniLabel);
            EditorGUILayout.Space(4f);
        }

        private static void DrawHistoryButton(NNImportFinderSession.HistoryEntry entry)
        {
            Object folder = AssetDatabase.LoadAssetAtPath<DefaultAsset>(entry.path);
            GUIContent content = new GUIContent(entry.displayName, entry.path);

            using (new EditorGUI.DisabledScope(folder == null))
            {
                if (GUILayout.Button(content, GUILayout.Height(30f)))
                {
                    Selection.activeObject = folder;
                    EditorGUIUtility.PingObject(folder);
                    EditorApplication.RepaintProjectWindow();
                }
            }
        }

        internal static void RepaintOpenWindows()
        {
            NNImportFinderWindow[] windows = Resources.FindObjectsOfTypeAll<NNImportFinderWindow>();
            foreach (NNImportFinderWindow window in windows)
                window.Repaint();
        }
    }
}
